namespace NetworkSimulator
{
	public class VertexConfig
	{
		private int buffer;
		private int _base;
		private int genLimit;
		private FindRoute routeFunc;
		private float fullLoadRatio;
		
		public int Buffer
		{
			get
			{
				return this.buffer;
			}
		}
		
		public int Base
		{
			get
			{
				return this._base;
			}
		}
		
		public int GenLimit
		{
			get
			{
				return this.genLimit;
			}
		}
		
		public FindRoute RouteFunc
		{
			get
			{
				return this.routeFunc;
			}
		}
		
		public float FullLoadRatio
		{
			get
			{
				return this.fullLoadRatio;
			}
		}
		
		public VertexConfig( int buf, int bas, int gen, float flratio, FindRoute rtfunc )
		{
			this.buffer = buf;
			this._base = bas;
			this.genLimit = gen;
			this.fullLoadRatio = flratio;
			this.routeFunc = rtfunc;
		}
	}
}

