using System.Collections.Generic;

namespace NetworkSimulator
{
	//	Declaration of the routing function delegate
	public delegate List<Vertex> FindRoute( int hndlSource, int hdnlDestination );
}
