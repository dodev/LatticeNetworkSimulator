using System;
using System.Collections.Generic;

namespace NetworkSimulator
{
	///
	/// A class to represent a vertex in the graph.
	/// Holds a list with the messages currently in him
	/// (aka memory); contains a method to route messages;
	/// has a limit of messages in the list.
	///
	public class Vertex: IListable
	{
		private int vertHandler;
		private int x;
		private int y;
		
		private VertexConfig config;
		
		private Queue<int> memory;
		private Queue<int> genMemory;
		private Queue<int> recieveMemory;
		
		private int currentProcQ;
		private int currentGenerateQ;
		private int currentRecieveQ;
		
		public int Handler
		{
			get { return this.vertHandler; }
		}
		
		public int X
		{
			get
			{
				return this.x;
			}
		}
		
		public int Y
		{
			get
			{
				return this.y;
			}
		}
		
		public Vertex( int handler, VertexConfig conf )
		{
			this.vertHandler = handler;
			this.config = conf;
			
			this.initMemory();
		}
		
		public Vertex( int handler, VertexConfig conf, int _x, int _y )
		{
			this.vertHandler = handler;
			this.config = conf;
			
			this.x = _x;
			this.y = _y;
			
			this.initMemory();
		}
		
		private void initMemory()
		{
			this.memory = new Queue<int>();
			this.genMemory = new Queue<int>();
			this.recieveMemory = new Queue<int>();
			
			this.currentProcQ = 0;
			this.currentGenerateQ = 0;
			this.currentRecieveQ = 0;
		}
		
		public bool Recieve( Message msg )
		{
			if ( this.IsFull() )
				return false;
			/*
			//	message has reached dest
			if ( msg.Destination == this.Handler )
			{
				msg.CurrentStatus = MsgStat.JustRecieved;
				msg.CurrentVrt = this.Handler;
				this.recieveMemory.Enqueue( msg.Handler );
				//	TODO: remove the next line when everything else is done
				//msg.Recieved = true;
			}
			//	or will stop for a cup of coffee before the next hop
			else
			{
			*/
				memory.Enqueue( msg.Handler );
				msg.CurrentVrt = this.Handler;
			//}
			
			return true;
		}
		
		///
		///	Calculating the maximum number of actions for the current iteration
		///
		public void CalculateCurrentQueue()
		{
			this.currentProcQ = ( memory.Count > this.config.Base ) ? this.config.Base : memory.Count;
			this.currentGenerateQ = this.genMemory.Count;
			this.currentRecieveQ = this.recieveMemory.Count;
		}
		
		///
		///	Returns the load ratio (0;1) for the genMemory queue
		///
		public float StatusGenerating()
		{
			if ( this.config.GenLimit != 0 )
				return (float)this.genMemory.Count / (float)this.config.GenLimit;
			else
				return 0f;
		}
		
		/*
		///
		///	Returns the load ration (0;1) for the recieveMemory queue
		///
		public float StatusRecieving()
		{
			if ( this.recieveCapacity != 0f )
				return (float)this.recieveMemory.Count / (float)this.recieveCapacity;
			else
				return 0f;
		}
		
		///
		///	Returns the load ration (0;1) for the memory queue
		///
		public float StatusSending()
		{
			if ( this.limit != 0f )
				return (float)(this.memory.Count - this.currentProcQ) / (float)this.config.Buffer;
			else
				return 0f;
		}
		*/
		///
		///	Returns the overall load ratio of the instance
		///
		public float Status()
		{
			if ( this.config.Buffer != 0 )
			{
				float inTheBuffer = (float)(this.memory.Count - this.currentProcQ) / (float)this.config.Buffer;
				return inTheBuffer + this.StatusGenerating()*0.01f + this.recieveMemory.Count*0.001f;
			}
			else
				return 0f;
		}
		/*
		public bool IsBusy()
		{
			return this.memory.Count == this.limit;
		}
		*/
		public bool IsFull()
		{
			return this.Status() > this.config.FullLoadRatio;
		}
		
		public void AddMsg( int msgHndl )
		{
			this.genMemory.Enqueue( msgHndl );
		}
		
		public void Iterate( MessageList msgList )
		{
			Message tmpMsg;
			/*
			for ( int i = 0; i < this.currentRecieveQ; i++ )
			{
				msgList.Find( this.recieveMemory.Dequeue() ).CurrentStatus = MsgStat.Recieved;
			}
			for ( int i = 0; i < this.currentGenerateQ; i++ ){}
			for ( int i = 0; i < this.currentProcQ; i++ ){}
			*/
			
			//	processing recieved messages from the previous iteration
			while ( this.currentRecieveQ > 0)
			{
				msgList.Find( this.recieveMemory.Dequeue() ).CurrentStatus = MsgStat.Recieved;
				this.currentRecieveQ--;
			}
			
			//	adding freshly created messages to the main queue
			//	if there is no space left, add them back to the gen queue
			while (this.currentGenerateQ > 0 )
			{
				tmpMsg = msgList.Find( this.genMemory.Dequeue() );
				if ( this.IsFull() )
				{
					this.genMemory.Enqueue( tmpMsg.Handler );
				}
				else
				{
					this.memory.Enqueue( tmpMsg.Handler );
					tmpMsg.CurrentStatus = MsgStat.OnTheWay;
				}
				this.currentGenerateQ--;				
			}
			
			//	sending messages in the base
			while ( this.currentProcQ > 0 )
			{
				tmpMsg = msgList.Find( this.memory.Dequeue() );
				//	if the message has reached its final destination
				if ( this.Handler == tmpMsg.Destination )
				{
					tmpMsg.CurrentStatus = MsgStat.JustRecieved;
					this.recieveMemory.Enqueue( tmpMsg.Handler );
				}
				//	if the message has been successfully sent remove it from the memory,
				//	put it in the end of the queue, otherwise.
				else if ( this.sendMsg( tmpMsg ) == false )
				{
					this.memory.Enqueue( tmpMsg.Handler );
				}
				this.currentProcQ--;
			}
		}
		
		private bool sendMsg( Message msg )
		{
			List<Vertex> psblNxtStp = this.config.RouteFunc( this.Handler, msg.Destination );
			
			foreach ( Vertex vrt in psblNxtStp )
			{
				if ( vrt.Recieve( msg ) )
					return true;
			}
			
			return false;
		}
		
		/* Traversing a queue is not a good idea!!!
		public List<int> GetMsgList()
		{
			int initMemCnt = this.memory.Count;
			List<int> msgList = new List<int>(initMemCnt);
			
			for( int i = 0; i < initMemCnt; i++ )
			{
				msgList.Add(this.memory.Dequeue());
				this.memory.Enqueue(msgList[i]);
			}
			
			return msgList;
		}
		*/
	}
}

