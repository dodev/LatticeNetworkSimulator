namespace NetworkSimulator
{
	public enum MsgStat
	{
		JustCreated,
		OnTheWay,
		Waiting,
		JustRecieved,
		Recieved
	}
}

