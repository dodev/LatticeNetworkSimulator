using System.Drawing;

namespace NetworkSimulator
{
	public static class GraphicalElements
	{
		public static Bitmap VertexImage = new Bitmap("images\\vertix.png");
		
		
	}
}

