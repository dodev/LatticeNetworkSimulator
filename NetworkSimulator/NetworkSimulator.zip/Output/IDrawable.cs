namespace NetworkSimulator
{
	public interface IDrawable
	{
		void Draw( System.Drawing.Bitmap image );
	}
}
