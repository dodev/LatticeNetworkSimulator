namespace NetworkSimulator
{
	public interface IListable
	{
		int Handler
		{
			get;
		}
	}
}

