using System;
using System.Windows.Forms;

namespace NetworkSimulator
{
	public partial class SettingsForm : Form
	{
		public SettingsForm()
		{
			this.InitComponents();
		}
	}
}

