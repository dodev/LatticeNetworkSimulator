using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;
using System.Threading;

namespace NetworkSimulator
{
	public partial class MainForm : Form
	{
		MapImage map;
		Session session;
		Thread simulation;
		
		///
		/// Default construcor
		///
		public MainForm()
		{
			int hNodes = 6;	//	num columns
			int vNodes = 5; //	num rows
			int _base = 4;	//	elements processed per interval
			int buffer = 10;//	elements in the queue
			int genLimit = 3;//	max num of created elements on a vertex per interval
			float maxLoadRatio = 0.97f; //	load ration on which a vertex is considered FULL
			
			this.InitComponents();
			
			
			
			this.map = new MapImage( this.mapWidth, this.mapHeight, hNodes, vNodes );
			
			this.session = new Session( hNodes, vNodes, _base, buffer, genLimit, maxLoadRatio, false );
			
			this.map.InitGraph( session.VrtList, session.EdgeList );
			
			this.map.SetMsgList( session.MsgList );

			this.picBoxMap.Image = map.Image;
			
			this.simulation = new Thread(this.simulate);
			
		}
		
		/*
		private void tester()
		{
			
			System.Drawing.Bitmap flag = new System.Drawing.Bitmap(200, 100);
		    System.Drawing.Graphics flagGraphics = System.Drawing.Graphics.FromImage(flag);
		    int red = 0;
		    int white = 11;
		    while (white <= 100) {
		        flagGraphics.FillRectangle(System.Drawing.Brushes.Red, 0, red, 200,10);
		        flagGraphics.FillRectangle(System.Drawing.Brushes.White, 0, white, 200, 10);
		        red += 20;
		        white += 20;
		    }
			
			this.picBoxMap.Image = flag;
		}
		
		
		private void demo()
		{
			this.picBoxMap.Image = new System.Drawing.Bitmap( "demo_1.png" );
			this.comboBoxDimensions.Items.Add( "5 x 6 elements" );

		}
		*/
		
		private void buttonTest_OnClick( object o, EventArgs e)
		{			
			this.simulation.Start();
		}
		
		private void buttonSettings_OnClick( object o, EventArgs e)
		{
			SettingsForm sf = new SettingsForm();
			sf.ShowDialog();
			sf.BringToFront();
		}
		
		private void simulate()
		{
			while ( this.session.SessionIterate( 1, 1 ) == true )
			{
				this.map.Draw();
				
				this.picBoxMap.Image = this.map.Image;
				this.picBoxMap.Refresh();
				
				Thread.Sleep( 2000 );
			}
		}
			
	}
}

