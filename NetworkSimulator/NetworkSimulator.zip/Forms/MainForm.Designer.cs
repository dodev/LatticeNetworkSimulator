namespace NetworkSimulator
{
	public partial class MainForm
	{
		/// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if ( disposing && ( components != null ))
            {
                components.Dispose();
            }
            base.Dispose( disposing );
        }
		
		/// <summary>
		/// Initializes the components of the Form 
		/// </summary>
		private void InitComponents()
		{
			this.groupBoxImages = new System.Windows.Forms.GroupBox();
			this.groupBoxImages.SuspendLayout();
			this.groupBoxControls = new System.Windows.Forms.GroupBox();
			this.groupBoxControls.SuspendLayout();
			this.groupBoxConsole = new System.Windows.Forms.GroupBox();
			this.groupBoxConsole.SuspendLayout();
			this.picBoxMap = new System.Windows.Forms.PictureBox();
			this.comboBoxDimensions = new System.Windows.Forms.ComboBox();
			this.labelDim = new System.Windows.Forms.Label();
			this.textBoxNumPkg = new System.Windows.Forms.TextBox();
			this.buttonTest = new System.Windows.Forms.Button();
			this.buttonSettings = new System.Windows.Forms.Button();
			this.listBoxConsole = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			
			//
			// buttonTest
			//
			this.buttonTest.Location = new System.Drawing.Point( 845, 145 );
			this.buttonTest.Size = new System.Drawing.Size( 160, 25 );
			this.buttonTest.Text = "Test me";
			this.buttonTest.Name = "buttonTest";
			this.buttonTest.Click += new System.EventHandler(this.buttonTest_OnClick);
			
			//
			// buttonSettings
			//
			this.buttonSettings.Location = new System.Drawing.Point( 845, 180 );
			this.buttonSettings.Size = new System.Drawing.Size( 160, 25 );
			this.buttonSettings.Text = "Settings";
			this.buttonSettings.Name = "buttonSettings";
			this.buttonSettings.Click += new System.EventHandler(this.buttonSettings_OnClick);
			
			//
			// picBoxMap
			//
			this.picBoxMap.Location = new System.Drawing.Point( 20, 25 );
			this.picBoxMap.Size = new System.Drawing.Size( this.mapWidth, this.mapHeight );
			this.picBoxMap.TabStop = false;
			this.picBoxMap.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picBoxMap.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			//this.picBoxMap.Image = new System.Drawing.Bitmap( "default.png" ); TODO: add initializing function and check in case of broken path to file.
			
			//
			// comboBoxDimensions
			//
			this.comboBoxDimensions.Location = new System.Drawing.Point( 845, 50 );
			this.comboBoxDimensions.Size = new System.Drawing.Size( 160, 25 );
			this.comboBoxDimensions.Name = "comboBoxDimensions";
			this.comboBoxDimensions.FormattingEnabled = false;
			// TODO: да махна възможността за въвеждане на текст в полето
			
			//
			// labelDim
			//
			this.labelDim.Location = new System.Drawing.Point( 845, 30 );
			this.labelDim.AutoSize = true;
			this.labelDim.Text = "Dimensions:";
			this.labelDim.Name = "labelDim";
			
			//
			// textBoxNumPkg
			//
			this.textBoxNumPkg.Location = new System.Drawing.Point( 845, 105 );
			this.textBoxNumPkg.Size = new System.Drawing.Size( 160, 25 );
			this.textBoxNumPkg.Name = "textBoxNumPkg";
			
			//
			// listBoxConsole
			//
			this.listBoxConsole.Location = new System.Drawing.Point( 15, 645 );
			this.listBoxConsole.Size = new System.Drawing.Size( 995, 115 );
			this.listBoxConsole.Name = "listBoxConsole";
			
			//
			// groupBoxImages 
			//
			this.groupBoxImages.Location = new System.Drawing.Point( 10, 10 );
			this.groupBoxImages.Size = new System.Drawing.Size( 820, 620 );
			this.groupBoxImages.Name = "groupBoxImages";
			this.groupBoxImages.Text = "Map";
			this.groupBoxImages.ResumeLayout( false );
			
			
			//
			// groupBoxControls
			//
			this.groupBoxControls.Location = new System.Drawing.Point( 835, 10 );
			this.groupBoxControls.Size = new System.Drawing.Size( 180, 620 );
			this.groupBoxControls.Name = "groupBoxControls";
			this.groupBoxControls.Text = "Controls";
			this.groupBoxControls.ResumeLayout( false );
			
			//
			// groupBoxConsole
			//
			this.groupBoxConsole.Location = new System.Drawing.Point( 10, 630 );
			this.groupBoxConsole.Size = new System.Drawing.Size( 1005, 130 );
			this.groupBoxConsole.Name = "groupBoxConsole";
			this.groupBoxConsole.Text = "Console";
			this.groupBoxConsole.ResumeLayout( false );
			
			//
			// MainForm
			//
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.MaximizeBox = false;
			this.ClientSize = new System.Drawing.Size( 1024, 768 );
			this.Name = "MainForm";
			this.Text = "Network Simulator";
			this.Controls.Add( this.buttonTest );
			this.Controls.Add( this.buttonSettings );
			this.Controls.Add( this.picBoxMap );
			this.Controls.Add( this.comboBoxDimensions );
			this.Controls.Add( this.labelDim );
			this.Controls.Add( this.textBoxNumPkg );
			this.Controls.Add( this.listBoxConsole );
			this.Controls.Add( this.groupBoxImages );
			this.Controls.Add( this.groupBoxControls );
			this.Controls.Add( this.groupBoxConsole );
			this.ResumeLayout( false );
            this.PerformLayout();
			
		}
		
		private System.Windows.Forms.GroupBox groupBoxImages;
		private System.Windows.Forms.GroupBox groupBoxControls;
		private System.Windows.Forms.GroupBox groupBoxConsole;
		private System.Windows.Forms.PictureBox picBoxMap;
		private System.Windows.Forms.ComboBox comboBoxDimensions;
		private System.Windows.Forms.Label labelDim;
		private System.Windows.Forms.TextBox textBoxNumPkg;
		private System.Windows.Forms.Button buttonTest;
		private System.Windows.Forms.Button buttonSettings;
		private System.Windows.Forms.ListBox listBoxConsole;
		
		private int mapWidth = 800;
		private int mapHeight = 600;
		
	}
}
